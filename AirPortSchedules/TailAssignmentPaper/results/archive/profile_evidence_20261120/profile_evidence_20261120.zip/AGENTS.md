# AGENTS.md — Tail Assignment Paper Project

## Project Identity
This is a scientific computing project that reproduces, corrects, and extends
the compact MILP formulation for the **Tail Assignment Problem** (Khaled et al.,
*European Journal of Operational Research* 264, 2018, pp. 548–557).

## Repository Map
```
src/model.py                  Pyomo MILP + greedy/insertion heuristic (main entry point)
src/generate_instances.py     Deterministic JSON instance generator
src/convert_data.py           DAT ↔ JSON converter
src/diagnostics.py            IIS finder + constraint-group deactivation scan
experiments/run_batch.py      Batch runner over a parameterised instance grid
experiments/reproduce_tables.py  Reproduce paper Tables 5, 6, 10, 11
experiments/configs/          JSON parameter grids (one file per table)
data/instances/               Problem instances (JSON, naming: DataCplex_density=D_p=P_h=H_test_I.json)
results/tables/               CSV outputs from experiments (git-ignored, re-runnable)
results/reference/            Baseline batch summary for validation
paper/main.tex                Master LaTeX document
paper/sections/               One .tex file per section (1_intro.tex … 8_conclusion.tex)
paper/refs.bib                BibTeX references
docs/model_math.tex           Formal mathematical derivations of the MILP
docs/heuristic_math.tex       Formal derivation of the greedy/insertion heuristic
```

## Key Mathematical Entities

| Symbol | Meaning |
|--------|---------|
| `F`    | Set of flight legs, indexed by `i` |
| `P`    | Set of aircraft (tail numbers), indexed by `j` |
| `A`    | Set of airports, indexed by `k` |
| `x[i,j]` | Binary: flight `i` assigned to aircraft `j` |
| `z[i,j,d,c]` | Binary: check `c` triggered after flight `i` for aircraft `j` on day `d` |
| `y[j,d,c]` | Binary: aircraft `j` undergoes check `c` on day `d` |
| `mega[j,d,c]` | Binary: aircraft `j` has check of level ≥ `c` on day `d` (hierarchy) |
| `c_ij` | Cost of assigning flight `i` to aircraft `j` |
| `Δt`   | Minimum ground turn time between flights |
| `T_max`| Maximum cumulative flight hours between A/B checks |
| `d_max`| Maximum calendar days between C/D checks |

## Constraint (13) — Profile-Specific Policy

The printed Khaled row and the historical endpoint split are diagnostic legacy
profiles, not exact A-hour models. The split repairs some endpoint patterns but
misses the both-endpoints-checked interval. Preserve both only for controlled
comparisons under an explicit printed day-pair range and calendar `d_max`.

The shared corrected A-only profile is:
```
  L_{d,d'} <= T_max + M_{dd'} * sum(y[r], r=d+1..d'-1)
  Phi + P_t <= T_max + M0_t * sum(y[r], r=1..t-1)
```
for every `1 <= d < d' <= n_d` and every `t`. The opening prefix includes
pre-horizon hours in both the left side and its big-M. Option A and Option B
reuse these hour rows and differ only by overnight executability policy.

Implementation and named profiles are in `src/model.py`. Treat
`event_historical_unverified` as audit-only until it passes the shared replay
and counterexample battery.

## Code Conventions

- **Solver**: Use the installed CPLEX Studio executable via Pyomo (`SolverFactory('cplex')`) in this workspace. Always pass `time_limit`.
- **Instance naming**: `DataCplex_density={d}_p={p}_h={h}_test_{idx}.json`.
  `density` ∈ {0.5, 0.75, 0.8, 1.0}, `p` = # aircraft, `h` = horizon in days.
- **Outputs**: Every script writes to `results/tables/` (CSV) or `results/figures/` (PNG).
  Never write to `data/` or `src/`.
- **Random seeds**: use `stable_seed(density, p, h, index)` in `src/generate_instances.py`
  for reproducibility.
- **Constraint toggles**: Maintenance, routing C2-C3, overlap/clique, hierarchy,
  capacity, sparse triggers and day-specific bounds are enabled by default.
  Sanity, strong links/conflicts, global triggers, routing/maintenance
  reachability, tight C13-M, paper C13 and soft coverage are opt-in.
  Use `use_maintenance=False` for routing without maintenance; this alone
  does not remove overlap constraints.

## How to Run (Quick Reference)

```powershell
# Activate environment
.\venv\Scripts\Activate.ps1

# Single instance, full maintenance model
python src/model.py --mode milp \
  --data data/instances/DataCplex_density=1_p=10_h=7_test_0.json \
  --solver cplex --time-limit 60

# Batch over a folder
python src/model.py --mode batch --input-dir data/instances/ --solver cplex

# Reproduce Table 5 (quick subset)
python experiments/reproduce_tables.py --table 5 --quick --solver cplex

# Diagnose infeasibility
python src/diagnostics.py --data data/instances/ABCD_all_checks_test.json --mode both
```

### Large fleet / long horizon (control z-variable blow-up)

Without a deferral cap, A/B check candidate days span the *entire remaining
horizon* for every maintenance-eligible flight, which is why instances like
30 aircraft / 14 days can reach ~475k `z` variables. Use
`--max-hour-check-deferral-days` (cap the A/B deferral window) and
`--only-checks` / `--disable-checks` to restrict active check types. The default
deferral cap is three days; explicit `none` restores the unrestricted remaining
horizon. A cap removes candidate schedules, and removing check types changes
the maintenance requirements. Neither is an exact feasible-region-preserving
reduction. The station-wait `--reachability`/`--maint-reachability` filter is
also experimental and restrictive; omit it from equivalence comparisons.

```powershell
# Full model via src/model.py CLI
python src/model.py --mode milp `
  --data data/instances/DataCplex_density=1_p=30_h=14_test_0.json `
  --solver highs `
  --time-limit 500 `
  --max-hour-check-deferral-days 3 `
  --only-checks A

# LP lower bound experiment harness (also exposes the deferral cap)
python experiments/step4_lp_lower_bounds.py `
  --input-dir data/instances/ --pattern "*p=30_h=14*.json" `
  --solver highs --time-limit 120 `
  --max-hour-check-deferral-days 3 --enabled-checks A `
  --sparse-z --tight-c13-m
```

`step4_lp_lower_bounds.py`'s output CSV now includes a `z_vars` column
(`scheduler.z_var_count`) so the effect of these flags is directly visible
per run.

For unrestricted runs use `--max-hour-check-deferral-days none`. The Step 4
`--routing-preflight` option checks a maintenance-free routing LP and skips only
proven infeasible instances; it is off by default pending end-to-end timing
evidence. `--include-routing-infeasible` bypasses it explicitly. CSV rows are
flushed incrementally, with audit, metadata and log sidecars; `--resume` requires
the same source, input hashes and settings. The verified CPLEX 12.9 protocol,
optional HiGHS commands and later thesis-update protocol are in
`docs/REPRODUCIBILITY.md`, Section 13. Use fixed solver/thread/cap settings and
fresh output paths for revised code; do not enable preflight for routine
known-feasible runs unless its filtering benefit has been measured.

Commit `828d3f0` used an implicit three-day cap and a weaker LP relaxation that
reset all binary bounds to `[0,1]`. Step 4's explicit
`--lp-relaxation legacy-unit-bounds` reproduces that procedure; the default
`preserve-bounds` retains the model's zero/other bounds. Label and compare those
LP policies separately. CPLEX `--threads 0` selects automatic threads; it is
not accepted as an automatic-thread option for other backends in this wrapper.

The `CPLEX.exe` and `CPLEXamp.exe` files in the old AMPL folder are identical
32-bit ASL binaries. Renaming/selecting the other file does not fix their
large-model memory failure. CPLEX long runs require a fully licensed 64-bit
installation; do not treat this ASL `CPLEX.exe` as an interactive CPLEX CLI.

`src/`, `experiments/` and `tests/` are authoritative. Keep the Python files in
`Thesis/code/src/`, `Thesis/code/experiments/`, and `Thesis/code/tests/`
identical to their repository-root counterparts; keep
`Thesis/code/requirements.txt` aligned with the root dependency manifest.
Nested dated releases under `Thesis/code/releases/` are historical snapshots
and should not be silently rewritten. Removed snapshots and their creation
commits are recorded in `Thesis/Versions.md`.

## Agent Task Prompts

Located in `.github/prompts/`:
- `write-paper.prompt.md`        — draft / extend paper sections
- `run-experiments.prompt.md`    — execute experiment grids, interpret outputs
- `validate-results.prompt.md`   — compare results against reference baselines
- `reproduce-tables.prompt.md`   — reproduce specific Khaled et al. tables

## Paper Sections Overview

| File | Content |
|------|---------|
| `1_intro.tex` | Motivation, airline planning pipeline, TAP definition |
| `2_literature.tex` | Comparison with set-partitioning, multi-commodity flow, time-space network models |
| `3_basic_model.tex` | Basic MILP: constraints C1–C4, Proposition 1 & 2, illustrative example |
| `4_maintenance_model.tex` | Extended model with maintenance; **constraint (13) correction** |
| `5_hierarchy_extension.tex` | Full A/B/C/D hierarchy; C13b (pre-horizon hours); C14b (multi-day checks) |
| `6_heuristics.tex` | Greedy/insertion heuristic; complexity; gap analysis |
| `7_computational.tex` | Reproduced Tables 5/6/10/11; corrected results; new instance classes |
| `8_conclusion.tex` | Summary of contributions, limitations, future work |

## Solver Environment

- **CPLEX 22.x** is the reference solver (matches Khaled et al.).
- All time limits quoted in the paper use wall-clock seconds, not CPU ticks.
- `--no-presolve` flag in CPLEX corresponds to `solver.options['preprocessing presolve'] = 0`
  in `run_batch.py`. Paper Tables 5/6 report results with and without presolve.

## Do NOT

- Do NOT commit large LP/log files.
- Do NOT modify `data/instances/` files — they are the canonical test set.
- Do NOT change the `stable_seed` formula in `src/generate_instances.py`;
  doing so invalidates reproducibility claims.
- Do NOT use `Model_28Oct.py` (legacy); use `src/model.py` exclusively.
