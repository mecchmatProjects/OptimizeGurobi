The instances are structured as follows: 

the first line indicates the number of jobs, the second line the number of machines. 
The first column indicates p_j, the second r_j, the third d_j, and the last w_j.
